# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['hello', 'hello.scripts']

package_data = \
{'': ['*']}

install_requires = \
['colorama>=0.4.6,<0.5.0']

entry_points = \
{'console_scripts': ['say-hello = hello.scripts.say_hello:main']}

setup_kwargs = {
    'name': 'hello',
    'version': '0.1.0',
    'description': 'A simple program that prints on the screen Hello!',
    'long_description': '',
    'author': 'pavelgrebenkov',
    'author_email': 'pavellearnnow@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
